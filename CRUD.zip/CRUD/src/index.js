import app from "./app";
import './database'

app.listen(3000);
console.log("Servidor trabajando en el puerto: ", 3000);