//Se importa el modelo de la Colección
import Tarea from "../models/Tarea";

//Controlador que renderiza las tareas
export const renderTareas = async (req, res) => {
  const tareas = await Tarea.find().lean();
  res.render("index", { tareas: tareas });
};

//Controlador que crea nuevas tareas
export const crearTareas = async (req, res) => {
  try {
    const tarea = Tarea(req.body);
    await tarea.save();
    res.redirect("/");
  } catch (error) {
    console.log(error);
  }
};

//Controlador que lee las tareas existentes
export const leerTareas = async (req, res) => {
  try {
    const task = await Tarea.findById(req.params.id).lean();
    res.render("edit", { task });
  } catch (error) {
    console.log(error.message);
  }
};

//Controlador que actualiza una tarea especifica
export const actualizarTareas = async (req, res) => {
  const { id } = req.params;
  await Tarea.findByIdAndUpdate(id, req.body);
  res.redirect("/");
};

//Controlador que elimina una tarea especifica
export const eliminarTareas = async (req, res) => {
  const { id } = req.params;
  await Tarea.findByIdAndDelete(id);
  res.redirect("/");
};

//Controlador que cambia el estado de la tarea (Si se ha realizado o no)
export const cambioTarea = async (req, res) => {
  const { id } = req.params;
  const tar = await Tarea.findById(id);
  tar.termino = !tar.termino;
  await tar.save();
  res.redirect("/");
};