//Se importa solo el modulo Router de express y los controladores
import { Router } from "express";
import {
  renderTareas,
  crearTareas,
  leerTareas,
  actualizarTareas,
  eliminarTareas,
  cambioTarea,
} from "../controllers/tareas.controller";

const router = Router();

//Ruta raiz
router.get("/", renderTareas);

//Ruta para saber si la tarea se ha realizado o no
router.get("/tareas/:id/toggleDone", cambioTarea);

//Ruta para insertar documentos
router.post("/tareas/add", crearTareas);

//Ruta para leer/consultar documentos
router.get("/tareas/:id/edit", leerTareas);

//Ruta para actualizar documentos
router.post("/tareas/:id/edit", actualizarTareas);
//Las 2 rutas anteriores van de la mano ya que ambas se utilizan en la misma vista, asi que deben de llevar la misma ruta

//Ruta para eliminar documentos
router.get("/tareas/:id/delete", eliminarTareas);

export default router;