//Se importan los modulos Schema y model de mongoose
import { Schema, model } from "mongoose";

//Creación del modelo de la coleccion (Asi apareceran los documentos de la misma)
const tareaSchema = new Schema({
  tarea: {
    type: String,
    unique: true,
    required: true,
    trim: true
  },
  descrip:{
    type: String,
    required: true,
    trim: true
  },
  termino: {
    type: Boolean,
    required: true,
    default: false
  }
},
{
  timestamps: true,  
  versionKey: false
});

export default model("tarea", tareaSchema);