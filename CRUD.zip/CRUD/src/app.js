//Se importa express y morgan, junto con los modulos necesarios: create, path. Además se importan las rutas del archivo correspondiente
import express from "express";
import indexRoutes from "./routes/index.routes";
import path from "path";
import { create } from "express-handlebars";
import morgan from "morgan";

const app = express();

//Configurando las vistas
app.set("views", path.join(__dirname, "/views"));

//Configuración del motor de plantillas
var hbs = create({
  layoutsDir: path.join(app.get("views"), "layouts"),
  defaultLayout: "main",
  partialsDir: path.join(app.get("views"), "partials"),
  extname: ".hbs",
});
app.engine(".hbs", hbs.engine);
app.set("view engine", ".hbs");

//Middleware
app.use(morgan("dev"));
app.use(express.urlencoded({extended:false}))

//Rutas
app.use(indexRoutes);

//Declaración de los archivos estaticos
app.use(express.static(path.join(__dirname, "public")));

export default app;