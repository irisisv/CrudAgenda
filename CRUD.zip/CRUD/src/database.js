//Importando el modulo connect de mongoose
import { connect } from "mongoose";

 //Se crea una funcion autoejecutable asincrona que contiene la conexión, utilizando bloques try-catch
(async () => {
  try {
    const db = await connect("mongodb://127.0.0.1:27017/proyecto-crud");
    console.log("Conectado exitosamente a la BD: ", db.connection.name);
  } catch (error) {
    console.log("Error al conectarse a la BD: " + error);
  }
})();
